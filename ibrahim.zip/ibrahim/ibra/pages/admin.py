from django.contrib import admin
from .models import Signnup
from .models import Contact

admin.site.register(Signnup)
admin.site.register(Contact)